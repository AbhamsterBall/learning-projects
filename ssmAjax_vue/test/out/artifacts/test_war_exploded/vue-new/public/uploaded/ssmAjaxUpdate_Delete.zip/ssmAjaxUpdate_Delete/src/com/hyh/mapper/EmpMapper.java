package com.hyh.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hyh.model.Emp;

public interface EmpMapper extends BaseMapper<Emp> {
}
