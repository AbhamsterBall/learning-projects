package com.hyh.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hyh.model.Emp;

public interface EmpService extends EntityService<Emp>, IService<Emp> {
}
